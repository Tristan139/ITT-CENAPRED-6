# Beamer Template

:sushi:

## Usage

### Local

1. Clone this repo
1. Run following command:

```
latexmk -r latexmkrc main.tex
```
